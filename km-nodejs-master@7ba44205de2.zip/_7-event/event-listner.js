// require function to include the 'events' module
var events = require('events');

// Create a new events emitter
var EventEmitter = events.EventEmitter;
var eventEmitter = new EventEmitter();

// creating a new event handler for the 'newListener' event
eventEmitter.on("newListener", function(eventName, listener) {
    console.log("Added listener for " + eventName + " events", listener);
});

// bind the event, to a callback function
eventEmitter.on('data-received', function () {
    console.log('data received successfully first...!!!');
});

// bind the event, to a callback function
eventEmitter.on('data-received', function () {
    console.log('data received successfully second...!!!');
});

// Get listener count
console.log('Total number of listeners for "data-received": ', EventEmitter.listenerCount(eventEmitter, 'data-received'));
