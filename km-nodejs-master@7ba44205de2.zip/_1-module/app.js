// The basic functionality of the "require" function is that it reads a JavaScript file, executes the file, and then proceeds to return an object.
// Using this object, one can then use the various functionality available in the module called by the require function.
var Addition = require('./Addition.js');

// Since the functions in the Addition.js file are now accessible, we can now make a call to the AddNumber function
console.log(Addition.AddNumber(1, 2));