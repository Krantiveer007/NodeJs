// include the 'fs' modules which contain all the functionality required to create streams.
var fs = require("fs");

// creating a writable stream by using the method – createWriteStream.
var stream = fs.createWriteStream("./test-file.txt");

// using the stream.write a method to write the different lines of text to file
stream.write("Tutorial on Node.js\n");
stream.write("Introduction\n");
stream.write("Test file\n");
stream.write("Write using file stream");