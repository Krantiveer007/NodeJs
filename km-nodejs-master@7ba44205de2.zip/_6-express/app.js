// using the "require" keyword to include the express module.
var express = require('express');

// created an object of the express module.
// Once done, the required methods of the express module can be invoked.
var app = express();

// creating a callback function - called whenever anybody browses to the root of our web application [http://localhost:8082].
// This responds with "Hello World" on the homepage
app.get('/', function (req, res) {
    console.log("Got a GET request for the homepage");
    res.send('Hello from express - GET request received');
});

// This responds a POST request for the homepage
app.post('/', function (req, res) {
    console.log("Got a POST request for the homepage");
    res.send('Hello from express - POST request received');
});

// This responds a DELETE request for the /del_user page.
app.delete('/del_user', function (req, res) {
    console.log("Got a DELETE request for /del_user");
    res.send('Hello from express - DELETE request received');
});

// This responds a GET request for the /list_user page.
app.get('/list-user', function (req, res) {
    console.log("Got a GET request for /list-user");
    res.send('Page Listing');
});

// This responds a GET request for abcd, abxcd, ab123cd, and so on
app.get('/ab*cd', function (req, res) {
    console.log("Got a GET request for /ab*cd");
    res.send('Page Pattern Match');
});

// using the listen method to make the application listen on 8082 port
var server = app.listen(8082, function () {
    var host = server.address().address;
    var port = server.address().port;

    console.log("App listening at http://%s:%s", host, port)
});