### Introduction

#### What is Node.js?
- Node.js is also based on the JavaScript framework
- Node.js is an open-source, cross-platform runtime environment
- Node.js is based on an event-driven architecture and a non-blocking Input/Output API
- based on a stateless model
- two-way connections, where both the client and server can initiate communication, allowing them to exchange data freely

#### Why use Node.js?
- work in real-time and have a 2-way communication. The state is maintained, and the either the client or server can start the communication.

#### Features of Node.js
- Asynchronous event driven IO helps concurrent request handling
    ```javascript
	var fs = require('fs');
	fs.readFile("Sample.txt", function (error, data) {
	    console.log("Reading Data completed");
	});
	```
	The important fraction of code to notice is the declaration of the function ('function(error,data)'). This is known as a callback function
- Node uses the V8 JavaScript Runtime engine
- Node has a wrapper over the JavaScript engine which makes the runtime engine much faster and hence processing of requests within Node also become faster
- Handling of concurrent requests
- There are an Active and vibrant community for the Node.js framework. Because of the active community, there are always keys updates made available to the framework

#### When to Use Node.js
Node.js is best for usage in streaming or event-based real-time applications
- Chat applications
- Game servers
- Good for collaborative environment
- Advertisement servers
- Streaming servers

Node.js is good when you need high levels of concurrency but less amount of dedicated CPU time.
Best of all, since Node.js is built on javascript, it's best suited when you build client-side applications which are based on the same javascript framework.

#### When to not use Node.js
- if there are long processing times which is required by the application.
- Node is structured to be single threaded. If any application is required to carry out some long running calculations in the background. So if the server is doing some calculation, it won't be able to process any other requests

### Modules: Create, Publish, Extend & Manage
Node.js framework is available for a variety of operating systems right from Windows to Ubuntu and OS X

Node.js also has the ability to embedded external functionality or extended functionality by making use of custom modules. These modules have to be installed separately. An example of a module is the MongoDB module

On windows, the node package manager is known as Chocolatey, however on mac or linux, once can use brew to install node js

#### What are modules in Node.js?
- modules in Node js are a way of encapsulating code in a separate logical unit
- Some of the popular modules
    - Express framework – Express is a minimal and flexible Node js web application framework that provides a robust set of features for the web and Mobile applications.
    - Socket.io - Socket.IO enables real-time bidirectional event-based communication. This module is good for creation of chatting based applications.
    - Jade - Jade is a high-performance template engine and implemented with JavaScript for node and browsers
    - MongoDB - The MongoDB Node.js driver is the officially supported node.js driver for MongoDB.
    - Restify - restify is a lightweight framework, similar to express for building REST APIs
    - Bluebird - Bluebird is a fully featured promise library with focus on innovative features and performance

#### Creating NPM modules

```
Reference: _1-module
```
  
#### Extending modules

```
Reference: _2-module-extend
```

#### NPM 

```
Reference: _3-npm
``` 

### Http: Create Server

```
Reference: _4-http
```

#### Making GET request

```
Reference: _5-request
```

### Express

```
Reference: _6-express
```

### Events

```
Reference: _7-events
```

### File stream and Pipes

```
Reference: _8-file-stream
```

### Promises

```
Reference: _9-promise
```

### Mongo DB
It is a NoSQL database.