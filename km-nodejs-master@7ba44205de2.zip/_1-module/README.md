Node.js has the ability to create custom modules and allows you to include those custom modules in your Node.js application.

#### Module
```javascript
module.exports.someFunc = function () {
    // code goes here...
}
```

#### Module Wrapper
```javascript
(function(exports, require, module, __filename, __dirname) {
// Module code actually lives in here
});
```

By doing this, Node.js achieves a few things:
- It keeps top-level variables (defined with var, const or let) scoped to the module rather than the global object.
- It helps to provide some global-looking variables that are actually specific to the module, such as:
    - The module and exports objects that the implementor can use to export values from the module.
    - The convenience variables __filename and __dirname, containing the module's absolute filename and directory path.

#### exports shortcut
The exports variable is available within a module's file-level scope, and is assigned the value of module.exports before the module is evaluated.

if a new value is assigned to exports, it is no longer bound to module.exports
```javascript
module.exports.hello = true; // Exported from require of module
exports = { hello: false };  // Not exported, only available in the module
```

Hypothetical implementation of require()
```javascript 1.6
function require(/* ... */) {
  const module = { exports: {} };
  ((module, exports) => {
    // Module code here. In this example, define a function.
    function someFunc() {}
    exports = someFunc;
    // At this point, exports is no longer a shortcut to module.exports, and
    // this module will still export an empty default object.
    module.exports = someFunc;
    // At this point, the module will now export someFunc, instead of the
    // default object.
  })(module, module.exports);
  return module.exports;
}
```