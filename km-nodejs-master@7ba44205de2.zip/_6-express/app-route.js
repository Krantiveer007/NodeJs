var express = require('express');

var app = express();

// Defining a new route 'route-1' with GET method
app.route('/route-1').get(function (req, res) {
    res.send("Hello from route 1...!!!");
});

// Defining a new route 'route-2' with GET method
app.route('/route-2').get(function (req, res) {
    res.send("Hello from route 2...!!!");
});

app.get('/', function (req, res) {
    res.send('Hello from root...!!!');
});

// Defining a new route 'route-3' with GET method
// TODO - Will it work ?
app.get('/route-3', function (req, res) {
    res.send('Hello from route 3...!!!');
});

// using the listen method to make the application listen on 8083 port
var server = app.listen(8083, function () {
    var host = server.address().address;
    var port = server.address().port;

    console.log("App listening at http://%s:%s", host, port)
});