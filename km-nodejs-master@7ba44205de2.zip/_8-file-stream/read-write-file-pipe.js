var fs = require("fs");

var readStream = fs.createReadStream("./data.txt");

var writeStream = fs.createWriteStream("./test-file-using-pipe.txt");

readStream.pipe(writeStream);
