// calls the "NodeTutorial" module.
var localTutor = require('./NodeTutorial.js');

// Create and save object
// By calling this function, the text "Node Tutorial" will be displayed in the console log.
var tutor = new localTutor.NodeTutorial();

// It also calls the tutorial module in the Tutorial.js module, and the text "Sample Tutorial" will be displayed to the console as well.
tutor.pTutor();