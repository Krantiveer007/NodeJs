// using the "require" function in the new module file itself.
// Since we are going to extend the existing module file "Tutorial.js", we need to first include it before extending it.
var Tutor = require('./Tutorial.js');

// create a function called "Nodetutorial." This function will do 2 things,
exports.NodeTutorial = function () {

    // send a string "Node Tutorial" to the console.
    console.log("Node Tutorial");

    // extended our Tutorial.js module and exposed a function called pTutor
    this.pTutor = function () {
        var PTutor = Tutor;

        // call the function from our Tutorial module, which will output the string "Sample Tutorial" to the console.log.
        PTutor.tutorial();
    }
};