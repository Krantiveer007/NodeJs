A Promise is a proxy for a value not necessarily known when the promise is created
It allows you to associate handlers to an asynchronous action's eventual success value or failure reason.

Any promise that performs async operations should call any one of the two methods resolve or reject

```javascript
var promise = new Promise(function(resolve, reject){
   ....
});
```

#### Methods
- Promise.all()
  Returns a promise that either fulfills when all of the promises in the iterable argument have fulfilled or rejects as soon as one of the promises in the iterable argument rejects.
  - If the returned promise fulfills, it is fulfilled with an array of the values from the fulfilled promises in the same order as defined in the iterable.
  - If the returned promise rejects, it is rejected with the reason from the first promise in the iterable that rejected.
- Promise.race()
  Returns a promise that fulfills or rejects as soon as one of the promises in the iterable fulfills or rejects, with the value or reason from that promise.
- Promise.reject()
  Returns a Promise object that is rejected with the given reason.
- Promise.resolve()
  Returns a Promise object that is resolved with the given value.
  
#### Async Await
The word “async” before a function means one simple thing: a function always returns a promise.
Even If a function actually returns a non-promise value, prepending the function definition with the “async” keyword directs Javascript to automatically wrap that value in a resolved promise.

```javascript
async function f() {
  return 1;
}
```

The keyword await makes JavaScript wait until that promise settles and returns its result.

```javascript 1.6
// works only inside async functions
let value = await promise;
```

Example:
```javascript
async function f() {

  let promise = new Promise((resolve, reject) => {
    setTimeout(() => resolve("done!"), 1000)
  });

  let result = await promise; // wait till the promise resolves (*)

  alert(result); // "done!"
}

f();
```
#### app.js