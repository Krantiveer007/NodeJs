// using the 'request' module.
// This module has the necessary functions which can be used to make GET requests.
var request = require("request");

// making a GET Request to www.google.com and subsequently calling a function when a response is received
/* Callback method
    - Error – In case there is any error received when using the GET request, this will be recorded here.
    - Response- The response will have the http headers which are sent back in the response.
    - Body- The body will contain the entire content of the response sent by Google.
 */
request("http://www.google.com", function (error, response, body) {

    // writing the content received in the body parameter to the console.log
    console.log(body);

});