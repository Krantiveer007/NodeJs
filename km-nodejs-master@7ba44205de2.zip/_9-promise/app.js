// since we want to use the functionality of http and we are using the require(http) command.
var fs = require('fs');
var http = require('http');

// ES 5
// A function to get data from JSON file
var readDataFromFile = function (path) {
    return new Promise(function (resolve, reject) {
        fs.readFile(path, 'utf8', function (error, data) {
            if (error) {
                reject(error);
            } else {
                resolve(JSON.parse(data));
            }
        });
    });
};

// ES 6
// const readDataFromFile = path => new Promise(
//     (resolve, reject) => fs.readFile(path, 'utf8', (error, data) => error ? reject(error) : resolve(JSON.parse(data)))
// );

// creating a server application which is based on a simple function
// This function is called, whenever a request is made to our server application
var server = http.createServer(function (req, res) {

    var headers = {'Content-Type': 'application/json'};

    readDataFromFile('./data.json').then(function (data) {

        // The writeHead function is used to send header data to the client
        res.writeHead(200, headers);

        // the end function will close the connection to the client.
        res.end(JSON.stringify(data));

    }).catch(function (error) {

        // The writeHead function is used to send header data to the client
        res.writeHead(500, headers);

        // the end function will close the connection to the client.
        res.end(JSON.stringify(error));

    });
});

// using the server.listen function to make our server application listen to client requests on port no 8080.
server.listen(8080);