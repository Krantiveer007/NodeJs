Node.js is a single-threaded application, but it can support concurrency via the concept of event and callbacks

Node.js is referred to as an Event-driven framework [uses observer pattern]
In an event-driven application, there is generally a main loop that listens for events, and then triggers a callback function when one of those events is detected.

![Alt text](assets/images/event-loop.PNG?raw=true)

Every API of Node.js is asynchronous and being single-threaded, they use async function calls to maintain concurrency

An event is something that happens

Example: in `createReadStream`, when data comes in stream from file, an event called as `data` is triggered.

#### EventEmitter Class
Methods
- addListener(event, listener)
- on(event, listener)
- once(event, listener)
- removeListener(event, listener)
- removeAllListeners([event])
- setMaxListeners(n)
- listeners(event)

#### events.js

#### event-one-time.js

#### event-listener.js

