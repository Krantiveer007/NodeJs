// Variable “module” is an object representing the current module.

// module.exports - It is the object reference that gets returned from the require() calls.
// automatically created by Node.js.
// just a reference to a plain JavaScript object
// empty by default
var exports = module.exports = {};

// defining a function called 'AddNumber'.
// This function is defined to take 2 parameters, a and b.
// The function is added to the module "exports" to make the function as a public function that can be accessed by other application modules.
exports.AddNumber = function (a, b) {

    console.log('File Name: ', __filename);
    console.log('Directory Name', __dirname);

    // returns the sum
    return a + b;
};