// require function to include the 'events' module
var events = require('events');

// Create a new events emitter
var EventEmitter = events.EventEmitter;
var eventEmitter = new EventEmitter();

// bind the event, to a callback function
eventEmitter.once('data-received', function () {
    console.log('data received successfully...!!!');
});

// manual trigger of the event
eventEmitter.emit('data-received');
eventEmitter.emit('data-received');