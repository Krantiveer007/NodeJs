// include the 'fs' modules which contain all the functionality required to create streams.
var fs = require("fs");

// create a readable stream by using the method – createReadStream.
// As an input, we give the location of data.txt file.
var stream = fs.createReadStream("./data.txt");

// an event handler with first parameter as 'data.' and then a callback function
stream.on("data", function (data) {

    // convert the data read from the file as a string
    var chunk = data.toString();

    // send the converted string as an output to the console
    console.log(chunk);
    
});