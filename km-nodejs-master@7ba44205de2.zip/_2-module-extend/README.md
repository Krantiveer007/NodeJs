When creating modules, it is also possible to extend or inherit one module from another.

#### Tutorial.js

#### NodeTutorial.js

#### app.js