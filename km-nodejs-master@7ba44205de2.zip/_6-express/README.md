#### What is Express.js?
Express.js is a Node js web application server framework, which is specifically designed for building single-page, multi-page, and hybrid web applications.

Easily handles multiple types of requests like the GET, PUT, and POST and DELETE requests.

**MEAN** Stack
- MongoDB - The standard NoSQL database
- Express.js - The default web applications framework
- Angular.js - The JavaScript MVC framework used for web applications
- Node.js - Framework used for scalable server-side and networking applications.

#### What are Routes?
Routing refers for determining the way in which an application responds to a client request to a particular endpoint.

Examples
- http://localhost:8082/Books
- http://localhost:8082/Students

```javascript
app.method[HEAD|GET|PUT|PATCH|POST|DELETE](PATH, HANDLER);
```

#### To install express
```bash
npm install express
```

#### app.js
[http://localhost:8082]

#### app-route.js
- [http://localhost:8083]
- [http://localhost:8083/route-1]
- [http://localhost:8083/route-2]
- [http://localhost:8083/route-3]

#### app-static.js
