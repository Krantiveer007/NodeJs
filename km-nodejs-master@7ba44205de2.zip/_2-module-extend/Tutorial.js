// The exports module is used so that whatever function is defined in this file can be available in other modules in Node.js
var exports = module.exports = {};

// creating a function called tutorial which can be used in other Node.js modules
exports.tutorial = function () {
    console.log("Sample Tutorial");
};