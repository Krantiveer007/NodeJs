var log = function (message) {
    console.log('Message from test package: ', message);
};

module.exports = {
    log: log
};