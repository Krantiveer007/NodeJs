Node Package Manager - manages modules, which are required by Node.js applications.

#### Commands

- Installing packages in global mode 
  ```bash
  npm install express –global
  ```
- Listing all of the global packages installed on a local machine
  ```bash
  npm list --global
  ```
- Installing a specific version of a package 
  ```bash
  npm install underscore@1.7.0
  ```
- Updating a package version
  ```bash
  npm update underscore
  ```
- Un-installing a package
  ```bash
  npm uninstall express
  ```      

Reference: _3-module-publishInitialize a npm repository

```bash
npm init
```

#### Package.json
The "package.json" file is used to hold the metadata about a particular project. This information provides the Node package manager the necessary information to understand how the project should be handled along with its dependencies.

The package.json files contains information such as the project description, the version of the project in a particular distribution, license information, and configuration data.

Reference [https://docs.npmjs.com/files/package.json] 

#### Login
Login onto the repository to publish
```bash
npm login --registry=xxx
```

#### Publish
One can publish their own module to their own package repository like npm or nexus
```bash
npm publish
```