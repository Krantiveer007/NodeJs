// using the "require" keyword to include the express module.
var express = require('express');

// created an object of the express module.
// Once done, the required methods of the express module can be invoked.
var app = express();

// Express provides a built-in middleware express.static to serve static files, such as images, CSS, JavaScript, etc.
app.use(express.static('htdocs'));

// creating a callback function - called whenever anybody browses to the root of our web application [http://localhost:8082].
// This responds with "Hello World" on the homepage
app.get('/', function (req, res) {
    res.send('Welcome to static server');
});

// using the listen method to make the application listen on 8084 port
var server = app.listen(8084, function () {
    var host = server.address().address;
    var port = server.address().port;

    console.log("App listening at http://%s:%s", host, port)
});