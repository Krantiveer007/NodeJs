We can make a simple GET request by using many of the existing modules like request | axios | jQuery

To install request
```bash
npm install request
```

#### app.js