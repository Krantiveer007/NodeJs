The Node.js framework is mostly used to create server based applications. 
The framework can easily be used to create web servers which can serve content to users.

#### app.js

#### app-json.js

#### app-json-file.js

#### web-server.js

[http://localhost:8080]