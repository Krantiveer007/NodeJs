// since we want to use the functionality of http and we are using the require(http) command.
var http = require('http');

// creating a server application which is based on a simple function
// This function is called, whenever a request is made to our server application
var server = http.createServer(function (req, res) {

    // The writeHead function is used to send header data to the client
    res.writeHead(200, {'Content-Type': 'application/json'});

    // the end function will close the connection to the client.
    res.end(JSON.stringify({
        id: 1,
        name: 'My Name'
    }));
});

// using the server.listen function to make our server application listen to client requests on port no 8080.
server.listen(8080);